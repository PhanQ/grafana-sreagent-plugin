/* [create-plugin] version: 5.19.8 */
define(["@grafana/ui","@emotion/css","module","@grafana/data","react"],((e,t,r,a,o)=>(()=>{"use strict";var l={7:t=>{t.exports=e},89:e=>{e.exports=t},308:e=>{e.exports=r},781:e=>{e.exports=a},959:e=>{e.exports=o}},n={};function i(e){var t=n[e];if(void 0!==t)return t.exports;var r=n[e]={exports:{}};return l[e](r,r.exports,i),r.exports}i.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return i.d(t,{a:t}),t},i.d=(e,t)=>{for(var r in t)i.o(t,r)&&!i.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},i.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),i.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},i.p="public/plugins/leapxpert-sreagent-panel/";var s={};i.r(s),i.d(s,{plugin:()=>h});var p=i(308),c=i.n(p);i.p=c()&&c().uri?c().uri.slice(0,c().uri.lastIndexOf("/")+1):"public/plugins/leapxpert-sreagent-panel/";var d=i(781);const m={appUrl:"",iframeSandboxAttributes:"allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-top-navigation"};var u=i(959),f=i.n(u),g=i(89),b=i(7);const x=()=>({wrapper:g.css`
      position: relative; // Needed for absolute positioning of potential overlays
      display: flex;
      flex-direction: column; // Stack elements vertically
      width: 100%;
      height: 100%;
      overflow: hidden; // Prevent wrapper from showing scrollbars
    `,iframe:g.css`
      flex-grow: 1; // Allow iframe to take available space
      border: none; // Remove default iframe border
      width: 100%;
      height: 100%; // Take full height of the allocated space
      display: block; // Ensure it behaves as a block element
    `,noticeBox:g.css`
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      flex-grow: 1; // Take up space if iframe isn't shown
      padding: 1rem;
      text-align: center;
      color: gray; // Use theme variable if available, otherwise fallback
      font-size: 1.1em;
    `,errorBox:g.css`
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      flex-grow: 1;
      padding: 1rem;
      text-align: center;
      background-color: rgba(234, 88, 88, 0.1);
      color: #b40000;
      border: 1px solid rgba(234, 88, 88, 0.2);
      border-radius: 4px;
      margin: 1rem;
    `,loadingContainer:g.css`
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: rgba(255, 255, 255, 0.7);
      z-index: 1;
    `,infoText:g.css`
      margin-top: 0.5rem;
      font-size: 0.85em;
      color: #5a5a5a;
    `,retryButton:g.css`
      margin-top: 1rem;
      padding: 0.5rem 1rem;
      background-color: #3274d9;
      color: white;
      border: none;
      border-radius: 2px;
      cursor: pointer;
      &:hover {
        background-color: #1f60c4;
      }
    `}),h=new d.PanelPlugin((({options:e,width:t,height:r})=>{const a=(0,b.useStyles2)(x),[o,l]=f().useState(!0),[n,i]=f().useState(null),{appUrl:s,iframeSandboxAttributes:p}=e;if(f().useEffect((()=>{l(!0),i(null)}),[s]),!s||""===s.trim())return f().createElement("div",{className:a.noticeBox},"Please configure the App URL in the panel options (Panel -> Edit -> Options).");let c=s.trim();try{/^https?:\/\//i.test(c)||(c="https://"+c),new URL(c)}catch(e){return f().createElement("div",{className:a.noticeBox},"Invalid App URL format provided: ",s,f().createElement("br",null),f().createElement("small",null,"URLs must be properly formatted with protocol (e.g., https://example.com)."))}return f().createElement("div",{className:(0,g.cx)(a.wrapper,g.css`width: ${t}px; height: ${r}px;`)},o&&!n&&f().createElement("div",{className:a.loadingContainer},f().createElement(b.LoadingPlaceholder,{text:"Loading Streamlit App..."})),n&&f().createElement("div",{className:a.errorBox},f().createElement("div",null,f().createElement("strong",null,"Failed to load content"),f().createElement("p",null,n),f().createElement("small",{className:a.infoText},"Check the browser console for more detailed error information. Verify that the app URL allows embedding via iframes.")),f().createElement("button",{className:a.retryButton,onClick:()=>{l(!0),i(null),setTimeout((()=>{const e=document.querySelector("iframe");e&&(e.src=c)}),100)}},"Retry Loading")),f().createElement("iframe",{className:a.iframe,style:{display:n?"none":"block"},src:c,title:"Streamlit Application",sandbox:p||void 0,referrerPolicy:"origin",onLoad:()=>{l(!1),i(null)},onError:e=>{l(!1),i("Failed to load the app in the iframe. Possible issues: CORS restrictions, server unavailable, or X-Frame-Options headers."),console.error(`Error loading iframe from ${c}:`,e)},allow:"clipboard-read; clipboard-write;"},"Your browser does not support iframes. Cannot display the SRE agent app."))})).setDefaults(m).setPanelOptions((e=>e.addTextInput({path:"appUrl",name:"SRE Agent App URL",description:"Full URL of the running SRE Agent application (required)",defaultValue:"",settings:{placeholder:"e.g., http://localhost:8501",required:!0},category:["App Settings"]}).addTextInput({path:"iframeSandboxAttributes",name:"Iframe Sandbox Attributes",description:'Space-separated security restrictions for the iframe (e.g., "allow-scripts allow-same-origin"). Leave empty for no sandbox (less secure).',defaultValue:m.iframeSandboxAttributes,settings:{placeholder:"allow-scripts allow-same-origin allow-forms"},category:["App Settings"]})));return s})()));
//# sourceMappingURL=module.js.map