# SRE Agent Panel for Grafana

This panel plugin allows you to embed and display the LeapXpert SRE Agent application directly within your Grafana dashboards.

## Features

* Embeds any accessible web application via its URL, specifically designed for the SRE Agent.
* Configurable application URL via panel options.
* Configurable `sandbox` attribute for the iframe for security control.
* Secure embedding with token-based authentication to prevent unauthorized access.
* Domain validation to ensure the app is only embedded from approved sources.
* Enhanced loading and error indicators with retry functionality.
* Responsive design that adapts to panel dimensions.
