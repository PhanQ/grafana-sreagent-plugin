# SRE Agent Panel for Grafana

This panel plugin allows you to embed and display the LeapXpert SRE Agent application directly within your Grafana dashboards.

## Features

* Embeds any accessible web application via its URL, specifically designed for the SRE Agent.
* Configurable application URL via panel options.
* Configurable `sandbox` attribute for the iframe for security control.
* Enhanced loading and error indicators with retry functionality.
* Responsive design that adapts to panel dimensions.

## Configuration

1.  **Install the Plugin:**
    * Build the plugin (`npm run build` or `yarn build`).
    * Copy the `dist` directory to your Grafana plugins directory (e.g., `/var/lib/grafana/plugins` or `data/plugins`).
    * Rename the copied `dist` directory to match the plugin ID (e.g., `leapxpert-sreagent-panel` - check `src/plugin.json`).
    * Restart the Grafana server.
2.  **Add Panel:**
    * Create or edit a dashboard in Grafana.
    * Add a new panel.
    * Select "SRE Agent Panel" from the visualization list.
3.  **Configure Options:**
    * Go to the panel editor's "Options" tab.
    * Under "App Settings":
        * Enter the full **SRE Agent App URL** where your application is running and accessible from the user's browser.
        * (Optional) Adjust the **Iframe Sandbox Attributes** if you need to change the security restrictions.

## Important Considerations

* **Accessibility:** The application **must** be running and network-accessible (HTTP/HTTPS) from the browsers of users viewing the Grafana dashboard.
* **CORS (Cross-Origin Resource Sharing):** Your application server might need to send appropriate headers (`Access-Control-Allow-Origin` or `Content-Security-Policy: frame-ancestors`) to permit embedding in an iframe hosted on your Grafana domain.
* **HTTPS:** If your Grafana is served over HTTPS, your embedded app generally must also be served over HTTPS to avoid mixed content browser errors.
* **Authentication:** If your application requires login, users will need to authenticate within the iframe separately, unless you implement a Single Sign-On (SSO) mechanism.
* **Security:** Review and configure the `iframeSandboxAttributes` option carefully based on the features your application requires. A more restrictive sandbox is generally safer.

## Troubleshooting

### Common Issues and Solutions

1. **Blank Panel / Failed to Load**
   * Verify the application is running and accessible by opening the URL directly in a browser
   * Check browser console for CORS errors
   * Ensure the application allows embedding via iframes (no `X-Frame-Options: deny` header)
   * Try using http:// protocol explicitly for local development URLs

2. **Security Restrictions**
   * If application features aren't working, you may need to adjust sandbox attributes
   * Common attributes needed:
     * `allow-scripts` - For JavaScript execution
     * `allow-same-origin` - For cookies and local storage
     * `allow-forms` - For form submission
     * `allow-popups` - For opening links in new tabs

3. **Authentication Issues**
   * The plugin doesn't pass authentication from Grafana to the embedded application
   * For internal apps, consider using service accounts or token-based authentication

## Advanced Configuration

### Sandbox Attributes

The iframe sandbox attribute controls what capabilities the embedded application has. By default, it includes:

```
allow-scripts allow-same-origin allow-forms allow-popups
```

You can customize this based on your security requirements. Available values include:

* `allow-scripts` - Allow JavaScript execution
* `allow-same-origin` - Allow the content to be treated as same-origin
* `allow-forms` - Allow form submission
* `allow-popups` - Allow popups
* `allow-popups-to-escape-sandbox` - Allow popups to open unsandboxed windows
* `allow-top-navigation` - Allow the iframe to navigate the top-level browsing context
* `allow-modals` - Allow modal dialogs
* `allow-downloads` - Allow downloads

### Panel Sizing

For best results:
* Set panel width to at least 1000px for comfortable viewing
* Adjust panel height based on your application's content
* Consider using "Fill" panel sizing mode for responsive layouts

## Examples

### Basic Configuration

1. Add the SRE Agent Panel to your dashboard
2. Configure with URL: `https://agent.obs.leapxpert.io`
3. Keep default sandbox attributes

### Local Development Setup

1. Add the SRE Agent Panel to your dashboard
2. Configure with URL: `http://localhost:8501` (note the explicit http:// protocol)
3. Use sandbox attributes: `allow-scripts allow-same-origin allow-forms allow-popups allow-top-navigation`

## Support

For issues related to this plugin, please contact the LeapXpert SRE team or submit issues to the internal GitHub repository.

